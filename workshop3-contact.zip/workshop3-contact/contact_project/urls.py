from django.contrib import admin
from django.urls import path

from contact_box.views import (person_create, 
    person_list, person_detail, person_delete,
    address_create, phone_create, email_create, person_modify,
    group_create, group_list, group_detail, group_modify, group_delete)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', person_list, name="person_list"),
    path('new-person/', person_create, name="new-person"),
    path('persons/<int:id>', person_detail, name="person_detail"),
    path('delete/<int:id>', person_delete, name="person_delete"),
    path('add-address/<int:person_id>', address_create, name="add-address"),
    path('persons/<int:person_id>/add-phone', phone_create, name="phone_create"),
    path('persons/<int:person_id>/add-email', email_create, name="email_create"),
    path('persons/<int:id>/update', person_modify, name="person_modify"),
    path('add-group/', group_create, name="add-group"),
    path('groups/', group_list, name="group_list"),
    path('groups/<int:id>', group_detail, name="group_detail"),
    path('groups/<int:id>/add-person', group_modify, name="group_modify"),
    path('groups/delete/<int:id>', group_delete, name="group_delete"),
]
