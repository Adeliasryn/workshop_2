from django.apps import AppConfig


class ContactBoxConfig(AppConfig):
    name = 'contact_box'
