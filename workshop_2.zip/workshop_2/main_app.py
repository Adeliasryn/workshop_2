from models.user import User
from psycopg2 import connect
import argparse


parser = argparse.ArgumentParser()
parser.add_argument("-u", "--username", dest="username", type=str)
parser.add_argument("-p", "--password", dest="password", type=str)
parser.add_argument("-l", "--list", dest="list", action='store_true')
parser.add_argument("-t", "--to", dest="recipient", type=str, default=False)
parser.add_argument("-s", "--send", dest="send", type=str, default=False)

def recognize_command(parser):
    datum = parser.parse_args()
    
    if datum.username and datum.password and datum.list:
        return CommandType.MESSAGE_LIST, {
            "username": datum.username,
            "password": datum.password
        }       

    if datum.username and datum.password and datum.send and datum.recipient:
        return CommandType.MESSAGE_SEND, {
            "username": datum.username,
            "password": datum.password,
            "message": datum.send,
            "recipient": datum.recipient
        }       

    return None, datum

DB_CONFIG = {
    "host": "localhost",
    "port": "5432",
    "user": "postgres",
    "password": "adel",
    "database": "workshop2_db",
}

cnx = connect(**DB_CONFIG)
cnx.autocommit = True
cursor = cnx.cursor()

# Create user
user = User()
user.username = ""
user.email = ""
user.set_password("adel")
user.save(cursor)

# Create message
message = messages()
messages.message = ""
messages.save(cursor)


# Load by id
user = User.load_by_id(cursor, 2)
message = messages.load_by_id(cursor, 2)

# Load all users
users = User.load_all(cursor)
for user in users:
   print(user.email)

# Load all messages
messages = Messages.load_all(cursor)
for message in messages:
   print(user.email)

# Modify by user
user = User.load_by_id(cursor, 2)
user.email = ""
user.set_password("adel")
user.save(cursor)

# Delete by user
user = User.load_by_id(cursor, 4)
user.delete(cursor)

# Checked Credential
user = User.load_by_id(cursor, 5)
is_matched = user.check_password("adel")