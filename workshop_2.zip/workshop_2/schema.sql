create table users (
	id serial,
	email varchar(255) unique,
	username varchar(255) unique,
	hashed_password varchar(80),
	primary key (id)
);

create table messages(
	id serial,
	message varchar(255),
	primary key(id),
	foreign key(user_id),
	references users(id) on delete cascade
);